%% Script Information
% Please read README.pdf for more info about the script.
% For a comprehensive understanding of our model and methodology, please
% refer to our papers:

% 1) Akhavanfar, M., Uchida, T. K., Clouthier, A. L., & Graham, R. B. (2022). 
% Sharing the load: modeling loads in OpenSim to simulate two-handed lifting. 
% Multibody System Dynamics, 54(2), 213�234. https://doi.org/10.1007/s11044-021-09808-7

% 2) Akhavanfar, M., Mir-Orefice, A., Uchida, T. k., & Graham, R. B. (2023). 
% An Enhanced Spine Model Validated for Simulating Dynamic Lifting Tasks in OpenSim. 
% Ann Biomed Eng. https://doi.org/10.1007/s10439-023-03368-x
%% Initialization
clearvars
clc
% Make sure OpenSim API 3.3 is installed properly before executing this MATLAB script
import org.opensim.modeling.*
%% User Setup
% Specify file paths and directories
% In this sample file, Squat-7 folder is within the following directory:
%"D:\Akhavanfar et al.(2023)- OpenSim and Matlab Files"
% Please modify the directory Squat-7 folder located on your computer 
APP3ModelFilePath=['D:\Akhavanfar et al. (2023)- OpenSim and Matlab Files\Squat-7\APP3\'];
TrialModelFilePath=['D:\Akhavanfar et al. (2023)- OpenSim and Matlab Files\Squat-7\APP4\'];
%% Generating the P2_APP4_SO Model
% P2_APP3_SO is loaded through MATLAB, and the Weld Constraint between
% half-boxes is removed from it
cd(APP3ModelFilePath);
SkeletalModel=Model(['P2_APP3_SO.osim']);
cd(TrialModelFilePath);
ConstSet=SkeletalModel.getConstraintSet();
ConstSet.remove(0);
SkeletalModel.updConstraintSet();
SkeletalModel.initSystem();
setupFile=['P2_APP4_SO.osim'];     
SkeletalModel.print([setupFile]);


    
