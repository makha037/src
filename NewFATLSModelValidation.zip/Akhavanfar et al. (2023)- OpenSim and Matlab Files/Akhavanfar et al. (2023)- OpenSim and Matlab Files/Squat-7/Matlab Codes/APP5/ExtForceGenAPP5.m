%% Script Information
% Please read README.pdf for more info about the script.
% For a comprehensive understanding of our model and methodology, please
% refer to our papers:

% 1) Akhavanfar, M., Uchida, T. K., Clouthier, A. L., & Graham, R. B. (2022). 
% Sharing the load: modeling loads in OpenSim to simulate two-handed lifting. 
% Multibody System Dynamics, 54(2), 213�234. https://doi.org/10.1007/s11044-021-09808-7

% 2) Akhavanfar, M., Mir-Orefice, A., Uchida, T. k., & Graham, R. B. (2023). 
% An Enhanced Spine Model Validated for Simulating Dynamic Lifting Tasks in OpenSim. 
% Ann Biomed Eng. https://doi.org/10.1007/s10439-023-03368-x
%% Initialization
clearvars
clc
% Make sure OpenSim API 3.3 is installed properly before executing this MATLAB script
import org.opensim.modeling.*
%% User Setup
% Specify file paths and directories
% In this sample file, Squat-7 folder is within the following directory:
%"D:\Akhavanfar et al.(2023)- OpenSim and Matlab Files"
% Please modify the directory Squat-7 folder located on your computer 
TrialModelFilePath=['D:\Akhavanfar et al. (2023)- OpenSim and Matlab Files\Squat-7\APP5\'];
cd(TrialModelFilePath);
%% External Force File Headings
% Define the number of columns in the external force file
s=37;
ss=num2str(s);
% Create cell array to store the external force file headings
textdata=cell(7,s);
textdata{1,1}='externalforce.mot';
textdata{2,1}='version=1';
textdata{4,1}=['nColumns=' ss];
textdata{5,1}=['inDegrees=yes'];
textdata{6,1}=['endheader'];
textdata{7,1}=['time']; 
textdata{7,2}=['ground_force1_vx']; 
textdata{7,3}=['ground_force1_vy']; 
textdata{7,4}=['ground_force1_vz']; 
textdata{7,5}=['ground_force1_px']; 
textdata{7,6}=['ground_force1_py']; 
textdata{7,7}=['ground_force1_pz']; 
textdata{7,8}=['ground_torque1_x']; 
textdata{7,9}=['ground_torque1_y']; 
textdata{7,10}=['ground_torque1_z']; 
textdata{7,11}=['ground_force2_vx']; 
textdata{7,12}=['ground_force2_vy']; 
textdata{7,13}=['ground_force2_vz']; 
textdata{7,14}=['ground_force2_px']; 
textdata{7,15}=['ground_force2_py']; 
textdata{7,16}=['ground_force2_pz']; 
textdata{7,17}=['ground_torque2_x']; 
textdata{7,18}=['ground_torque2_y']; 
textdata{7,19}=['ground_torque2_z']; 
textdata{7,20}=['Rhand_vx']; 
textdata{7,21}=['Rhand_vy']; 
textdata{7,22}=['Rhand_vz']; 
textdata{7,23}=['Rhand_px']; 
textdata{7,24}=['Rhand_py']; 
textdata{7,25}=['Rhand_pz']; 
textdata{7,26}=['Rhand_torque_x']; 
textdata{7,27}=['Rhand_torque_y']; 
textdata{7,28}=['Rhand_torque_z']; 
textdata{7,29}=['Lhand_vx']; 
textdata{7,30}=['Lhand_vy']; 
textdata{7,31}=['Lhand_vz']; 
textdata{7,32}=['Lhand_px']; 
textdata{7,33}=['Lhand_py']; 
textdata{7,34}=['Lhand_pz']; 
textdata{7,35}=['Lhand_torque_x']; 
textdata{7,36}=['Lhand_torque_y']; 
textdata{7,37}=['Lhand_torque_z'];
%% Reading Force Plate Data
% Load external force data from 'ExtForceAPP1.mot'
ExtForceAPP1=importdata(['ExtForceAPP1.mot']);
ExtForceAPP1Data=ExtForceAPP1.data();
MeasuredExtForceData=ExtForceAPP1Data(:,1:19);
ForcePlateFrames=length(MeasuredExtForceData);
tt=num2str(ForcePlateFrames);
% Update the number of rows in the external force file header
textdata{3,1}=['nRows=' tt];
%% Reading Motion Cycle times
motcyltime=load('motioncycletimes');
tcyl=motcyltime.t;
%% Calculaing Hand External Forces
% Load the box model
ModelFileName=['Load.osim'];
myModel=Model([ModelFileName]);
% Extract the inertial properties of the box
load=myModel.getBodySet().get(1);
m=load.getMass();
I=Mat33;
load.getInertia(I);
Ixx=I.get(0,0);
Iyy=I.get(1,1);
Izz=I.get(2,2);
g=-9.8066;

% Import Body Kinematics and States Reporter results for the box
% Fit curves to box velocities and differentiate to calculate accelerations
% Calculate forces (Fx, Fy, Fz) and moments (Mx, My, Mz)
LoadAnalysisDir=[TrialModelFilePath 'LoadAnalysis\'];
BKFileName=['Load_BodyKinematics_vel_global.sto'];
SRFileName=['Load_StatesReporter_states.sto'];
A=importdata([LoadAnalysisDir BKFileName]);
B=A.data;
t=B(:,1);
VGlob=B(:,8:10);
clear A B
% Vx fitting 
f1=fit(t,VGlob(:,1),'cubicspline')
[Vxdot,Vxddot]=differentiate(f1,t);
Fx=m*Vxdot;
% Vy fitting 
f2=fit(t,VGlob(:,2),'cubicspline')
[Vydot,Vyddot]=differentiate(f2,t);
Fy=m*(Vydot-g);
% Vz fitting 
f3=fit(t,VGlob(:,3),'cubicspline')
[Vzdot,Vzddot]=differentiate(f3,t);
Fz=m*Vzdot;
% Ext Force Vector
F=[Fx,Fy,Fz];      
A=importdata([LoadAnalysisDir SRFileName]);
B=A.data;
t=B(:,1);
W=B(:,8:10);
clear A B
% Wx fitting 
f4=fit(t,W(:,1),'cubicspline')
[Wxdot,Wxddot]=differentiate(f4,t);
Mx=Ixx*Wxdot;
% Wy fitting 
f5=fit(t,W(:,2),'cubicspline')
[Wydot,Wyddot]=differentiate(f5,t);
My=Iyy*Wydot;
% Wz fitting 
f6=fit(t,W(:,3),'cubicspline')
[Wzdot,Wzddot]=differentiate(f6,t);
Mz=Izz*Wzdot;
% Ext Moment Vector
Wdot=[Wxdot,Wydot,Wzdot];
M=[Mx,My,Mz];

% Transform forces and moments to box coordinate system
BKPosFileName=['Load_BodyKinematics_pos_global.sto']; 
A=importdata([LoadAnalysisDir BKPosFileName]);
B=A.data;
OriMat=B(:,11:13);      
    for x=1:length(t)       
        R=RotMat(OriMat(x,1),OriMat(x,2),OriMat(x,3));
        FBoxCoord(x,:)=(inv(R)*F(x,:)')';
    end   
    
% Use optimization to find forces applied to right and left handles (FRBoxCoord and FLBoxCoord)
% and their corresponding points of application (RCOPr and RCOPl)
% Based on Newton's third law, calculate hand external forces as -FRBoxCoord and -FLBoxCoord
t1=tcyl(1,1);
t2=tcyl(1,4);
t1round=floor(t1*100)/100;
t2round=floor(t2*100)/100;
n1=find(t(:,1)>t1round,1);
n2=find(t(:,1)>t2round,1);       
FRBoxCoord=zeros(length(t),3);
FLBoxCoord=zeros(length(t),3);
RCOPr=[zeros(length(t),1) zeros(length(t),1) -0.17*ones(length(t),1)];
RCOPl=[zeros(length(t),1) zeros(length(t),1) 0.17*ones(length(t),1)];      
    for kk=n1:n2
        fun = @(x)x(7)^2+x(8)^2+x(9)^2+x(10)^2+x(11)^2+x(12)^2
        x0 = zeros(12,1);
        lb=[-0.05;-0.05;-0.22;-0.05;-0.05;0.12;-inf;-inf;-inf;-inf;-inf;-inf];
        ub=[0.05;0.05;-0.12;0.05;0.05;0.22;inf;inf;inf;inf;inf;inf];
        Aeq = zeros(3,12);
        Aeq(1,7)=1;
        Aeq(1,10)=1;
        Aeq(2,8)=1;
        Aeq(2,11)=1;
        Aeq(3,9)=1;
        Aeq(3,12)=1;
        beq = FBoxCoord(kk,:)';
        A = [];
        b = [];
        nonlcon = NonlinearConst(@(x) x,M(kk,:));
        x = fmincon(fun,x0,A,b,Aeq,beq,lb,ub,nonlcon);
        RCOPr(kk,:)=[x(1,1),x(2,1),x(3,1)];
        RCOPl(kk,:)=[x(4,1),x(5,1),x(6,1)];
        FRBoxCoord(kk,:)=[x(7,1),x(8,1),x(9,1)];
        FLBoxCoord(kk,:)=[x(10,1),x(11,1),x(12,1)];
    end
% Based on Newton's third law, hand external forces are -FRBoxCoord and -FLBoxCoord
HandExtForceApp5=[-FRBoxCoord RCOPr zeros(length(t),3) -FLBoxCoord RCOPl zeros(length(t),3)];
%% Writing External Forces File
% Normalize hand forces to have the same vector length as force plate data
    for mm=1:18
        HandExtForceApp5Norm(:,mm)=normalize(HandExtForceApp5(:,mm),ForcePlateFrames-1);
    end
% Combine measured external forces and normalized hand forces    
Data=[MeasuredExtForceData HandExtForceApp5Norm];
% Write data to 'ExtForceAPP5.mot' file
fid = fopen('ExtForceAPP5.mot','wt');
    for nn=1:7
        fprintf(fid,'%s\t',textdata{nn,:});
        fprintf(fid,'\n');
    end
    for oo=1:ForcePlateFrames
        fprintf(fid,'%g\t',Data(oo,:));
        fprintf(fid,'\n');
    end
fclose(fid);    


