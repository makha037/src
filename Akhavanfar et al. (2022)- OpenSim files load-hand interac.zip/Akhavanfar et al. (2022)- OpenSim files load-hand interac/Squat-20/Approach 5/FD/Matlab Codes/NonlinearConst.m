function [c,ceq] = NonlinearConst(x,M)
c=[];
ceq(1) = x(2)*x(9)-x(3)*x(8)+x(5)*x(12)-x(6)*x(11)-M(1,1);
ceq(2) = x(3)*x(7)-x(1)*x(9)+x(6)*x(10)-x(4)*x(12)-M(1,2);
ceq(3) = x(1)*x(8)-x(2)*x(7)+x(4)*x(11)-x(5)*x(10)-M(1,3);
end