%% Script Information
% Please read README.pdf for more info about the script.
% For a comprehensive understanding of our model and methodology, please
% refer to our papers:

% 1) Akhavanfar, M., Uchida, T. K., Clouthier, A. L., & Graham, R. B. (2022). 
% Sharing the load: modeling loads in OpenSim to simulate two-handed lifting. 
% Multibody System Dynamics, 54(2), 213�234. https://doi.org/10.1007/s11044-021-09808-7

% 2) Akhavanfar, M., Mir-Orefice, A., Uchida, T. k., & Graham, R. B. (2023). 
% An Enhanced Spine Model Validated for Simulating Dynamic Lifting Tasks in OpenSim. 
% Ann Biomed Eng. https://doi.org/10.1007/s10439-023-03368-x
%% Initialization
clearvars
clc
% Make sure OpenSim API 3.3 is installed properly before executing this MATLAB script
import org.opensim.modeling.*
%% User Setup
% Specify file paths and directories
% In this sample file, Squat-7 folder is within the following directory:
%"D:\Akhavanfar et al.(2023)- OpenSim and Matlab Files"
% Please modify the directory Squat-7 folder located on your computer 
TrialModelFilePath=['D:\Akhavanfar et al. (2023)- OpenSim and Matlab Files\Squat-7\APP5\'];
cd(TrialModelFilePath);
%% Running Body Kinematics Analysis (BK) for the Box 
ModelFileName=['Load.osim'];
cutoff=3;% Cut-off frequency for low-pass filter
% Define prefixes and file paths
Prefix='Load';
BK_setup_file_name='LoadBKSetup.xml';
ikloadname='IKResultsLoad.mot';
ikloadfile=[TrialModelFilePath ikloadname];
% Load the IK results as a storage
ikloadresults=Storage(ikloadfile);
sTime=ikloadresults.getFirstTime();
fTime=ikloadresults.getLastTime();
% Create a BK analysis 
bk = BodyKinematics();
bk.setOn(true);
bk.setStartTime(sTime);
bk.setEndTime(fTime);
bk.setName('BodyKinematics');
% Set up the Analyze Tool and configure it for BK analysis
at = AnalyzeTool();
at.setModel(Model(ModelFileName));
at.setModelFilename(ModelFileName);
BKResultsDir='LoadAnalysis';
at.setResultsDir(BKResultsDir);
at.setInitialTime(sTime);
at.setFinalTime(fTime);
at.setSolveForEquilibrium(false);
at.setCoordinatesFileName(ikloadname);
at.setName(Prefix);
at.setLowpassCutoffFrequency(cutoff);
% Add BK to the Analyze Tool
at.getAnalysisSet().cloneAndAppend(bk);
% Print the BK setup file and run the analysis
at.print(BK_setup_file_name);
at = AnalyzeTool(BK_setup_file_name);
at.run();
% Remove the BK analysis set from the model
at.removeAnalysisSetFromModel();


   

