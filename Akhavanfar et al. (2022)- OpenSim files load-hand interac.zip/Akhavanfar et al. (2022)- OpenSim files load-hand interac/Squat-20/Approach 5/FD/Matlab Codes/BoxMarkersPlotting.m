clear all 
clc
a=importdata(['D:\PhD\Study 2 Results and Experiments\Akhavanfar et al. (2022)- OpenSim files load-hand interac\Squat-20\Approach 5\FD\Matlab Codes\BoxMarkers.xlsx'])
BoxMarkers=a.data;
clear a
WoodBoxTFR_Exp=BoxMarkers(:,1:3)/10;
WoodBoxTFL_Exp=BoxMarkers(:,4:6)/10;
WoodBoxTBL_Exp=BoxMarkers(:,7:9)/10;
WoodBoxTBR_Exp=BoxMarkers(:,10:12)/10;
WoodBoxFHL_Exp=BoxMarkers(:,13:15)/10;
WoodBoxBHL_Exp=BoxMarkers(:,16:18)/10;
WoodBoxFHR_Exp=BoxMarkers(:,19:21)/10;
WoodBoxBHR_Exp=BoxMarkers(:,22:24)/10;

Folder=['D:\PhD\Study 2 Results and Experiments\Akhavanfar et al. (2022)- OpenSim files load-hand interac\Squat-20\Approach 5\FD\Results\']
a=importdata([Folder 'JustBox_PointKinematics_WoodBox_TFR_pos.sto']);
WoodBoxTFRpos=a.data;
clear a
a=importdata([Folder 'JustBox_PointKinematics_WoodBox_TFL_pos.sto']);
WoodBoxTFLpos=a.data;
clear a
a=importdata([Folder 'JustBox_PointKinematics_WoodBox_TBL_pos.sto']);
WoodBoxTBLpos=a.data;
clear a
a=importdata([Folder 'JustBox_PointKinematics_WoodBox_TBR_pos.sto']);
WoodBoxTBRpos=a.data;
clear a
a=importdata([Folder 'JustBox_PointKinematics_WoodBox_FHL_pos.sto']);
WoodBoxFHLpos=a.data;
clear a
a=importdata([Folder 'JustBox_PointKinematics_WoodBox_BHL_pos.sto']);
WoodBoxBHLpos=a.data;
clear a
a=importdata([Folder 'JustBox_PointKinematics_WoodBox_FHR_pos.sto']);
WoodBoxFHRpos=a.data;
clear a
a=importdata([Folder 'JustBox_PointKinematics_WoodBox_BHR_pos.sto']);
WoodBoxBHRpos=a.data;
clear a
WoodBoxTFR_Calc=WoodBoxTFRpos(:,2:4)*100;
WoodBoxTFL_Calc=WoodBoxTFLpos(:,2:4)*100;
WoodBoxTBL_Calc=WoodBoxTBLpos(:,2:4)*100;
WoodBoxTBR_Calc=WoodBoxTBRpos(:,2:4)*100;
WoodBoxFHL_Calc=WoodBoxFHLpos(:,2:4)*100;
WoodBoxBHL_Calc=WoodBoxBHLpos(:,2:4)*100;
WoodBoxFHR_Calc=WoodBoxFHRpos(:,2:4)*100;
WoodBoxBHR_Calc=WoodBoxBHRpos(:,2:4)*100;

DeltaWoodBoxTFR=WoodBoxTFR_Calc-WoodBoxTFR_Exp;
for i=1:length(WoodBoxTFR_Calc)
dWoodBoxTFR(i,1)=vecnorm(DeltaWoodBoxTFR(i,:),2);
end
DeltaWoodBoxTFL=WoodBoxTFL_Calc-WoodBoxTFL_Exp;
for i=1:length(WoodBoxTFR_Calc)
dWoodBoxTFL(i,1)=vecnorm(DeltaWoodBoxTFL(i,:),2);
end
DeltaWoodBoxTBR=WoodBoxTBR_Calc-WoodBoxTBR_Exp;
for i=1:length(WoodBoxTFR_Calc)
dWoodBoxTBR(i,1)=vecnorm(DeltaWoodBoxTBR(i,:),2);
end
DeltaWoodBoxTBL=WoodBoxTBL_Calc-WoodBoxTBL_Exp;
for i=1:length(WoodBoxTFR_Calc)
dWoodBoxTBL(i,1)=vecnorm(DeltaWoodBoxTBL(i,:),2);
end
DeltaWoodBoxFHL=WoodBoxFHL_Calc-WoodBoxFHL_Exp;
for i=1:length(WoodBoxTFR_Calc)
dWoodBoxFHL(i,1)=vecnorm(DeltaWoodBoxFHL(i,:),2);
end
DeltaWoodBoxFHR=WoodBoxFHR_Calc-WoodBoxFHR_Exp;
for i=1:length(WoodBoxTFR_Calc)
dWoodBoxFHR(i,1)=vecnorm(DeltaWoodBoxFHR(i,:),2);
end
DeltaWoodBoxBHL=WoodBoxBHL_Calc-WoodBoxBHL_Exp;
for i=1:length(WoodBoxTFR_Calc)
dWoodBoxBHL(i,1)=vecnorm(DeltaWoodBoxBHL(i,:),2);
end
DeltaWoodBoxBHR=WoodBoxBHR_Calc-WoodBoxBHR_Exp;
for i=1:length(WoodBoxTFR_Calc)
dWoodBoxBHR(i,1)=vecnorm(DeltaWoodBoxBHR(i,:),2);
end
cycle=[0:1:100]';
dWoodBoxTFR=normalize(dWoodBoxTFR,100);
dWoodBoxTFL=normalize(dWoodBoxTFL,100);
dWoodBoxTBR=normalize(dWoodBoxTBR,100);
dWoodBoxTBL=normalize(dWoodBoxTBL,100);
dWoodBoxFHR=normalize(dWoodBoxFHR,100);
dWoodBoxFHL=normalize(dWoodBoxFHL,100);
dWoodBoxBHR=normalize(dWoodBoxBHR,100);
dWoodBoxBHL=normalize(dWoodBoxBHL,100);
figure('DefaultAxesFontSize',24)
plot(cycle,dWoodBoxTFR,'LineWidth',0.8)
hold on
plot(cycle,dWoodBoxTFL,'LineWidth',0.8)
hold on
plot(cycle,dWoodBoxTBR,'LineWidth',0.8)
hold on
plot(cycle,dWoodBoxTBL,'LineWidth',0.8)
hold on
plot(cycle,dWoodBoxFHR,'LineWidth',0.8)
hold on
plot(cycle,dWoodBoxFHL,'LineWidth',0.8)
hold on
plot(cycle,dWoodBoxBHR,'LineWidth',0.8)
hold on
plot(cycle,dWoodBoxBHL,'LineWidth',0.8)

legend({'TFR','TFL','TBR','TBL',...
    'HFR','HFL','HBR','HBL'},'EdgeColor',[1 1 1]);
xlabel('% Cycle')
ylabel({'Distance between the predicted and','measured box markers (cm) in Approach 5'})
title(['Squat' '--' '20'],'Interpreter','Latex')


