%% Script Information
% Please read README.pdf for more info about the script.
% For a comprehensive understanding of our model and methodology, please
% refer to our papers:

% 1) Akhavanfar, M., Uchida, T. K., Clouthier, A. L., & Graham, R. B. (2022). 
% Sharing the load: modeling loads in OpenSim to simulate two-handed lifting. 
% Multibody System Dynamics, 54(2), 213�234. https://doi.org/10.1007/s11044-021-09808-7

% 2) Akhavanfar, M., Mir-Orefice, A., Uchida, T. k., & Graham, R. B. (2023). 
% An Enhanced Spine Model Validated for Simulating Dynamic Lifting Tasks in OpenSim. 
% Ann Biomed Eng. https://doi.org/10.1007/s10439-023-03368-x
%% Initialization
clearvars
clc
% Make sure OpenSim API 3.3 is installed properly before executing this MATLAB script
import org.opensim.modeling.*
%% User Setup
% Specify file paths and directories
% In this sample file, Squat-7 folder is within the following directory:
%"D:\Akhavanfar et al.(2023)- OpenSim and Matlab Files"
% Please modify the directory Squat-7 folder located on your computer 
TrialModelFilePath=['D:\Akhavanfar et al. (2023)- OpenSim and Matlab Files\Squat-7\APP5\'];
cd(TrialModelFilePath);
%% Combining the Load and Body Motion Files   
% Load the motion data from 'IKResults.mot' and 'IKResultsLoad.mot'
App1Mot=importdata('IKResults.mot');
LoadMot=importdata('IKResultsLoad.mot');
App1MotData=App1Mot.data;
LoadMotData=LoadMot.data;
App1MotTextData=App1Mot.textdata;
LoadMotTextData=LoadMot.textdata;

% Combine the data from both motion files, keeping the time column from 'IKResults.mot'
Data=[LoadMotData,App1MotData(:,2:end)];

% Determine the number of columns and rows in the combined data
s=size(Data,2);
ss=num2str(s);
nrows=size(Data,1);
n=size(App1MotTextData,1);

% Combine the text data from both motion files
textdata=cell(n,s);
    for kk=1:n-1
        textdata{kk,1}=App1MotTextData{kk,1}; 
    end
textdata(n,:)=[LoadMotTextData(n,1:end),App1MotTextData(n,2:end)];

% Update the 'nColumns' value in the text data to match the new number of columns
Index = find(contains(textdata(:,1),'nColumns='));
textdata{Index,1}=['nColumns=' ss];

% Write the combined motion data and text data to 'IKResultsCombined.mot'
fid = fopen('IKResultsCombined.mot','wt');
    for kk=1:n
        fprintf(fid,'%s\t',textdata{kk,:});
        fprintf(fid,'\n');
    end

    for kk=1:nrows
        fprintf(fid,'%g\t',Data(kk,:));
        fprintf(fid,'\n');
    end
fclose(fid);




