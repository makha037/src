%% Script Information
% Please read README.pdf for more info about the script.
% For a comprehensive understanding of our model and methodology, please
% refer to our papers:

% 1) Akhavanfar, M., Uchida, T. K., Clouthier, A. L., & Graham, R. B. (2022). 
% Sharing the load: modeling loads in OpenSim to simulate two-handed lifting. 
% Multibody System Dynamics, 54(2), 213�234. https://doi.org/10.1007/s11044-021-09808-7

% 2) Akhavanfar, M., Mir-Orefice, A., Uchida, T. k., & Graham, R. B. (2023). 
% An Enhanced Spine Model Validated for Simulating Dynamic Lifting Tasks in OpenSim. 
% Ann Biomed Eng. https://doi.org/10.1007/s10439-023-03368-x
%% Initialization
clearvars
clc
% Make sure OpenSim API 3.3 is installed properly before executing this MATLAB script
import org.opensim.modeling.*
%% User Setup
% Specify the main directory
% In this sample file, Squat-7 folder is within the following directory:
%"D:\Akhavanfar et al.(2023)- OpenSim and Matlab Files"
% Please modify the directory Squat-7 folder located on your computer 
MainDir=['D:\Akhavanfar et al. (2023)- OpenSim and Matlab Files\Squat-7\'];
cd(MainDir)
%% Creating the Box Model with Markers in Box Coordinate System 
% Load the model with markers in ground reference frame
FileName=['Load_MrkGND.osim'];
myModel = Model(FileName);
myModel.initSystem();
initstate=myModel.getWorkingState();
bodies=myModel.getBodySet();
load=bodies.get(1);
markers=myModel.getMarkerSet();
nummarkers=markers.getSize();
% Iterate through markers and change their body location to the box
    for kk=1:nummarkers
        marker=markers.get(kk-1);
        marker.changeBodyPreserveLocation(initstate,load);
    end
% Initialize the model system and save it as 'Load.osim'
myModel.initSystem();
setupFile=['Load.osim'];     
myModel.print(setupFile);



