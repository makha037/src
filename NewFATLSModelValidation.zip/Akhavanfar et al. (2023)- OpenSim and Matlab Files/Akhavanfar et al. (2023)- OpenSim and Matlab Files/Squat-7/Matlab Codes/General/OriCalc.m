function theta = OriCalc(eRotMat)
 if eRotMat(1,3)<1
                    if eRotMat(1,3)>-1
                    thetay=asin(eRotMat(1,3));
                    thetax=atan2(-eRotMat(2,3),eRotMat(3,3));
                    thetaz=atan2(-eRotMat(1,2),eRotMat(1,1));

                    end
                    if eRotMat(1,3)==-1 
                    thetay=-pi()/2;
                    thetax=-atan2(eRotMat(2,1),eRotMat(2,2)) ;
                    thetaz=0;
                    end
                else
                thetay=pi()/2;
                thetax=atan2(eRotMat(2,1),eRotMat(2,2));
                thetaz=0;
 end
 theta=[thetax,thetay,thetaz];

end