function normdat = normalize(indat,numpoints)

%function normdat = normalize(indat,numpoints)
%This function transforms the data into x samples evenly spaced
%throughout the dataset(using a cubic spline- interpolation)

[nframes, ncols]= size(indat);
index= 1:nframes;
inc=(nframes-1)/numpoints; 
cycle= 1:inc:nframes;
%normalize each column
for i= 1:ncols
      normdat(:,i)= pchip(index,indat(:,i),cycle)'; %use a shape preserving spline
%     normdat(:,i)= spline(index,indat(:,i),cycle)'; %use a cubic spline
end; 
