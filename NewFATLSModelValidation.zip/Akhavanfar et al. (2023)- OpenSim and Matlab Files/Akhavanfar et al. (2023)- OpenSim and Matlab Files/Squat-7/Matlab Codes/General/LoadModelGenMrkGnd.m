%% Script Information
% Please read README.pdf for more info about the script.
% For a comprehensive understanding of our model and methodology, please
% refer to our papers:

% 1) Akhavanfar, M., Uchida, T. K., Clouthier, A. L., & Graham, R. B. (2022). 
% Sharing the load: modeling loads in OpenSim to simulate two-handed lifting. 
% Multibody System Dynamics, 54(2), 213�234. https://doi.org/10.1007/s11044-021-09808-7

% 2) Akhavanfar, M., Mir-Orefice, A., Uchida, T. k., & Graham, R. B. (2023). 
% An Enhanced Spine Model Validated for Simulating Dynamic Lifting Tasks in OpenSim. 
% Ann Biomed Eng. https://doi.org/10.1007/s10439-023-03368-x
%% Initialization
clearvars
clc
% Make sure OpenSim API 3.3 is installed properly before executing this MATLAB script
import org.opensim.modeling.*
%% User Setup
% Specify the main directory
% In this sample file, Squat-7 folder is within the following directory:
%"D:\Akhavanfar et al.(2023)- OpenSim and Matlab Files"
% Please modify the directory Squat-7 folder located on your computer 
MainDir=['D:\Akhavanfar et al. (2023)- OpenSim and Matlab Files\Squat-7\'];
cd(MainDir)
%% Creating the Box Model with Markers in Ground Reference Frame 

% Use '7kgBox_MrkGND_Sample.osim' as the basis for creating a box model for the specific trial (Squat-7).
SampleModelFileName=['7kgBox_MrkGND_Sample.osim'];

% Read marker data from the box with respect to the ground reference frame.
MeasuredMarkerFile=dir('*.trc');
MeasuredMarkerFileName=MeasuredMarkerFile.name();
MeasuredMarker=MarkerData(MeasuredMarkerFileName);

% Identify marker indices in the trc file.
TFR_index=MeasuredMarker.getMarkerIndex('TFR');
TFL_index=MeasuredMarker.getMarkerIndex('TFL');
TBR_index=MeasuredMarker.getMarkerIndex('TBR');
TBL_index=MeasuredMarker.getMarkerIndex('TBL');
FHR_index=MeasuredMarker.getMarkerIndex('FHR');
FHL_index=MeasuredMarker.getMarkerIndex('FHL');
BHR_index=MeasuredMarker.getMarkerIndex('BHR');
BHL_index=MeasuredMarker.getMarkerIndex('BHL');

% Extract marker positions and convert from mm to m.
A=Storage();
MeasuredMarker.makeRdStorage(A);
B=A.getStateVector(0);
C=B.getData();
Mrk1(1,1)=C.get(TFR_index*3)/1000;
Mrk1(1,2)=C.get(TFR_index*3+1)/1000;
Mrk1(1,3)=C.get(TFR_index*3+2)/1000;
Mrk2(1,1)=C.get(TFL_index*3)/1000;
Mrk2(1,2)=C.get(TFL_index*3+1)/1000;
Mrk2(1,3)=C.get(TFL_index*3+2)/1000;
Mrk3(1,1)=C.get(TBL_index*3)/1000;
Mrk3(1,2)=C.get(TBL_index*3+1)/1000;
Mrk3(1,3)=C.get(TBL_index*3+2)/1000;
Mrk4(1,1)=C.get(TBR_index*3)/1000;
Mrk4(1,2)=C.get(TBR_index*3+1)/1000;
Mrk4(1,3)=C.get(TBR_index*3+2)/1000;
Mrk5(1,1)=C.get(FHL_index*3)/1000;
Mrk5(1,2)=C.get(FHL_index*3+1)/1000;
Mrk5(1,3)=C.get(FHL_index*3+2)/1000;
Mrk6(1,1)=C.get(BHL_index*3)/1000;
Mrk6(1,2)=C.get(BHL_index*3+1)/1000;
Mrk6(1,3)=C.get(BHL_index*3+2)/1000;
Mrk7(1,1)=C.get(FHR_index*3)/1000;
Mrk7(1,2)=C.get(FHR_index*3+1)/1000;
Mrk7(1,3)=C.get(FHR_index*3+2)/1000;
Mrk8(1,1)=C.get(BHR_index*3)/1000;
Mrk8(1,2)=C.get(BHR_index*3+1)/1000;
Mrk8(1,3)=C.get(BHR_index*3+2)/1000;
Mrk=[Mrk1;Mrk2;Mrk3;Mrk4;Mrk5;Mrk6;Mrk7;Mrk8];

% Calculate the center of the load (box).
x=mean(Mrk(:,1));
y=Mrk1(1,2)-0.135;
z=mean(Mrk(:,3));
LoadCenter=[x y z];

% Define a coordinate system for the box.
e1=(Mrk4-Mrk1)/norm(Mrk4-Mrk1);
e3=(Mrk2-Mrk1)/norm(Mrk2-Mrk1);
e2=cross(e3,e1);
eRotMat=[e1' e2' e3'];

    if eRotMat(1,3)<1
        if eRotMat(1,3)>-1
        thetay=asin(eRotMat(1,3));
        thetax=atan2(-eRotMat(2,3),eRotMat(3,3));
        thetaz=atan2(-eRotMat(1,2),eRotMat(1,1));
        end
        if eRotMat(1,3)==-1 
        thetay=-pi()/2;
        thetax=-atan2(eRotMat(2,1),eRotMat(2,2)) ;
        thetaz=0;
        end
        else
        thetay=pi()/2;
        thetax=atan2(eRotMat(2,1),eRotMat(2,2));
        thetaz=0;
    end
theta=[thetax,thetay,thetaz];

% Create the load model representing the box with 8 markers in the ground (GND) reference frame.
myModel = Model(SampleModelFileName);
bodies=myModel.getBodySet();
load=bodies.get(1);
joint=load.getJoint();
A=Vec3(LoadCenter(1,1),LoadCenter(1,2),LoadCenter(1,3));
joint.setLocationInParent(A);
B=Vec3(thetax,thetay,thetaz);
joint.setOrientationInParent(B);
markers=myModel.getMarkerSet();
nummarkers=markers.getSize();

% Iterate through markers and set their offsets relative to the load.
    for ii=1:nummarkers
        marker=markers.get(ii-1);
        C=Vec3(Mrk(ii,1),Mrk(ii,2),Mrk(ii,3));
        marker.setOffset(C);
    end
    
% Initialize the model system and save it as 'Load_MrkGND.osim'.
myModel.initSystem();
setupFile=['Load_MrkGND.osim'];
myModel.print([setupFile]);
