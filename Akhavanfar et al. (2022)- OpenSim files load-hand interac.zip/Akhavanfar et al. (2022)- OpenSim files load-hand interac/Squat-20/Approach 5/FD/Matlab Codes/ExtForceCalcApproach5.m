clear all
clc

%%
% Calculating Trans ACC from BodyKinematics Global & Rotational Moments
% From States Speed

%%
% inertial properties of the lifted mass
m=20;
g=-9.8066;
Ixx=0.20833;
Iyy=0.20833;
Izz=0.20833;
A=importdata(['D:\PhD\Study 2 Results and Experiments\Akhavanfar et al. (2022)- OpenSim files load-hand interac\Squat-20\Approach 5\FD\'...
    'JustBox_BodyKinematics_vel_global.sto']);
B=A.data;
t=B(:,1);
VGlob=B(:,8:10);
clear A B
%%
% Vx fitting 
figure();
f1=fit(t,VGlob(:,1),'cubicspline')
scatter(t,VGlob(:,1))
hold on
plot(t,f1(t))
[Vxdot,Vxddot]=differentiate(f1,t);
Fx=m*Vxdot;

% Vy fitting 
figure();
f2=fit(t,VGlob(:,2),'cubicspline')
scatter(t,VGlob(:,2))
hold on
plot(t,f2(t))
[Vydot,Vyddot]=differentiate(f2,t);
Fy=m*(Vydot-g);

% Vz fitting 
figure();
f3=fit(t,VGlob(:,3),'cubicspline')
scatter(t,VGlob(:,3))
hold on
plot(t,f3(t))
[Vzdot,Vzddot]=differentiate(f3,t);
Fz=m*Vzdot;

F=[Fx,Fy,Fz];
clear A B
A=importdata(['D:\PhD\Study 2 Results and Experiments\Akhavanfar et al. (2022)- OpenSim files load-hand interac\Squat-20\Approach 5\FD\'...
    'JustBox_StatesReporter_states.sto']);
B=A.data;
t=B(:,1);
W=B(:,8:10);
clear A B
% Wx fitting 
figure();
f4=fit(t,W(:,1),'cubicspline')
scatter(t,W(:,1))
hold on
plot(t,f4(t))
[Wxdot,Wxddot]=differentiate(f4,t);
Mx=Ixx*Wxdot;
% Wy fitting 
figure();
f5=fit(t,W(:,2),'cubicspline')
scatter(t,W(:,2))
hold on
plot(t,f5(t))
[Wydot,Wyddot]=differentiate(f5,t);
My=Iyy*Wydot;
% Wz fitting 
figure();
f6=fit(t,W(:,3),'cubicspline')
scatter(t,W(:,3))
hold on
plot(t,f6(t))
[Wzdot,Wzddot]=differentiate(f6,t);
Mz=Izz*Wzdot;

Wdot=[Wxdot,Wydot,Wzdot];
a=[Vxdot,Vydot,Vzdot];
M=[Mx,My,Mz];
%%
%  Optimization
for i=1:length(t)
fun = @(x)x(7)^2+x(8)^2+x(9)^2+x(10)^2+x(11)^2+x(12)^2
x0 = zeros(12,1);
lb=[-0.05;-0.05;-0.22;-0.05;-0.05;0.12;-inf;-inf;-inf;-inf;-inf;-inf];
ub=[0.05;0.05;-0.12;0.05;0.05;0.22;inf;inf;inf;inf;inf;inf];
Aeq = zeros(3,12);
Aeq(1,7)=1;
Aeq(1,10)=1;
Aeq(2,8)=1;
Aeq(2,11)=1;
Aeq(3,9)=1;
Aeq(3,12)=1;
beq = F(i,:)';
A = [];
b = [];
nonlcon = NonlinearConst(@(x) x,M(i,:));
x = fmincon(fun,x0,A,b,Aeq,beq,lb,ub,nonlcon);
RCOPr(i,:)=[x(1,1),x(2,1),x(3,1)];
RCOPl(i,:)=[x(4,1),x(5,1),x(6,1)];
FRHandle(i,:)=[x(7,1),x(8,1),x(9,1)];
FLHandle(i,:)=[x(10,1),x(11,1),x(12,1)];
end








