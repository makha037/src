%% Script Information
% Please read README.pdf for more info about the script.
% For a comprehensive understanding of our model and methodology, please
% refer to our papers:

% 1) Akhavanfar, M., Uchida, T. K., Clouthier, A. L., & Graham, R. B. (2022). 
% Sharing the load: modeling loads in OpenSim to simulate two-handed lifting. 
% Multibody System Dynamics, 54(2), 213�234. https://doi.org/10.1007/s11044-021-09808-7

% 2) Akhavanfar, M., Mir-Orefice, A., Uchida, T. k., & Graham, R. B. (2023). 
% An Enhanced Spine Model Validated for Simulating Dynamic Lifting Tasks in OpenSim. 
% Ann Biomed Eng. https://doi.org/10.1007/s10439-023-03368-x
%% Initialization
clearvars
clc
% Make sure OpenSim API 3.3 is installed properly before executing this MATLAB script
import org.opensim.modeling.*
%% User Setup
% Specify file paths and directories
% In this sample file, Squat-7 folder is within the following directory:
%"D:\Akhavanfar et al.(2023)- OpenSim and Matlab Files"
% Please modify the directory Squat-7 folder located on your computer 
TrialModelFilePath=['D:\Akhavanfar et al. (2023)- OpenSim and Matlab Files\Squat-7\APP5\'];
cd(TrialModelFilePath);
%% Creating P2_APP5_SO Model
% Load the human model ('P2_APP1_SO.osim') and the box model
LoadModel=Model('Load.osim');
SkeletalModel=Model(['P2_APP1_SO.osim']);
% Modify the inertia properties of the Load (box) to a negligible mass
load=LoadModel.getBodySet.get(1);
mass=0.0001;
load.setMass(mass);
A=ArrayDouble();
A.setSize(6);
    for k=1:3
        A.setitem(k-1,0.0001);
    end
    for k=4:6
        A.setitem(k-1,0);
    end
load.setInertia(A);
% Add the modified Load model to the human model to create the combined model
SkeletalModel.addBody(load);
% Print the new combined model to a file ('P2_APP5_SO.osim')
setupFile=['P2_APP5_SO.osim'];     
SkeletalModel.print([TrialModelFilePath setupFile]);  


