%% Script Information
% Please read README.pdf for more info about the script.
% For a comprehensive understanding of our model and methodology, please
% refer to our papers:

% 1) Akhavanfar, M., Uchida, T. K., Clouthier, A. L., & Graham, R. B. (2022). 
% Sharing the load: modeling loads in OpenSim to simulate two-handed lifting. 
% Multibody System Dynamics, 54(2), 213�234. https://doi.org/10.1007/s11044-021-09808-7

% 2) Akhavanfar, M., Mir-Orefice, A., Uchida, T. k., & Graham, R. B. (2023). 
% An Enhanced Spine Model Validated for Simulating Dynamic Lifting Tasks in OpenSim. 
% Ann Biomed Eng. https://doi.org/10.1007/s10439-023-03368-x
%% Initialization
clearvars
clc
% Make sure OpenSim API 3.3 is installed properly before executing this MATLAB script
import org.opensim.modeling.*
%% User Setup
% Specify file paths and directories
% In this sample file, Squat-7 folder is within the following directory:
%"D:\Akhavanfar et al.(2023)- OpenSim and Matlab Files"
% Please modify the directory Squat-7 folder located on your computer 
TrialModelFilePath=['D:\Akhavanfar et al. (2023)- OpenSim and Matlab Files\Squat-7\APP3\'];
cd(TrialModelFilePath);
% Make sure you modify the directory where "Hands_BodyKinematics_pos_global.sto" file is located according to your computer
HandsBKFile=['D:\Akhavanfar et al. (2023)- OpenSim and Matlab Files\Squat-7\APP1\BK\Hands_BodyKinematics_pos_global.sto'];

%% Generating FlexInit.osim
% A new model file is created at the start of lifting by setting the default
% coordinate values of the original model to the IK results at this time (i.e., 0% motion cycle)
SkeletalModel=Model(['P2_APP1_IK.osim']);
load('motioncycletimes');
CoordSet=SkeletalModel.getCoordinateSet();
CoordSetSize=CoordSet.getSize();
A=importdata([TrialModelFilePath 'IKResults.mot']);
B=A.data;
tflexinit=t(1,1);
tflexinitround=floor(tflexinit*100)/100;
 FlexInitFrame=find(B(:,1)>=tflexinitround,1);
    for kk=0:CoordSetSize-1
    Coord=CoordSet.get(kk);
    RadAng=B(FlexInitFrame,kk+2)*pi/180;
    Coord.set_default_value(RadAng);
    end
    for mm=3:5
    Coord=CoordSet.get(mm);
    TransMetre=B(FlexInitFrame,mm+2);
    Coord.set_default_value(TransMetre);
    end
SkeletalModel.initSystem();
setupFile = 'FlexInit.osim';
SkeletalModel.print([TrialModelFilePath setupFile]);
clear A B C D
%% Generating FlexInitWithBox.osim
% In this section, we're creating the FlexInitWithBox.osim model by adding a lifted load (box model) to the human model.

% Create the LoadModel and FlexInitModel using provided .osim files.
LoadModel=Model('Load.osim');
FlexInitModel=Model('FlexInit.osim');
        
% Reading marker files to extract box markers info at the start of lifting.
MeasuredMarkerFile = dir('*.trc');
MeasuredMarkerFileName = MeasuredMarkerFile.name();
MeasuredMarker = MarkerData(MeasuredMarkerFileName);
        
% Body Kinematics data of hands is needed to obtain hand orientations.
% Import hand kinematics data.
A = importdata(HandsBKFile);
B = A.data;




% To establish a connection between the half-boxes (boxr and boxl) and the hands (handr and handl) using a Weld Joint,
% we need to determine both the position and orientation of the joint in the reference frames of both the parent (hands) 
% and child (boxr and boxl) bodies.
%
% Specifically:
% - We calculate the 3x3 rotation matrices (from_R_to) representing the orientation
%   of the "to" frame in the "from" frame. 
% - These rotation matrices are computed using Euler angles.
% - The RotMat function is used to generate the rotation matrix based on the
%   specified coordinate angles in degrees.
% - The OriCalc function then calculates the orientations based on these rotation matrices.

gnd_R_handr=RotMat(B(FlexInitFrame,5),B(FlexInitFrame,6),B(FlexInitFrame,7));
gnd_R_handl=RotMat(B(FlexInitFrame,11),B(FlexInitFrame,12),B(FlexInitFrame,13));
handr_R_gnd=inv(gnd_R_handr);
handl_R_gnd=inv(gnd_R_handl);
Load=LoadModel.getBodySet().get(1);
Joint=Load.getJoint();
C=Vec3();
Joint.getOrientationInParent(C);
gnd_R_weld=RotMat(C.get(0)*180/pi(),C.get(1)*180/pi(),C.get(2)*180/pi());
handr_R_weld=handr_R_gnd*gnd_R_weld;
handl_R_weld=handl_R_gnd*gnd_R_weld;
handr_O_weld=OriCalc(handr_R_weld);
handl_O_weld=OriCalc(handl_R_weld);
        
       
% The 'from_r_to' matrix represents the position of the "to" frame in the "from" frame.
% This section calculates and determines the positions of the hand coordinates in the ground reference frame.
% For instance, 'gnd_r_handr' illustrates the position of the right hand coordinates in the ground reference frame.
hand_R=FlexInitModel.getBodySet.get(64);
hand_L=FlexInitModel.getBodySet.get(70);
handrcom=Vec3();
handlcom=Vec3();
hand_R.getMassCenter(handrcom);
hand_L.getMassCenter(handlcom);
handr_r_handrcom=(gnd_R_handr*[handrcom.get(0);handrcom.get(1);handrcom.get(2)])';
handl_r_handlcom=(gnd_R_handl*[handlcom.get(0);handrcom.get(1);handrcom.get(2)])';   
gnd_r_handrcom=[B(FlexInitFrame,2),B(FlexInitFrame,3),B(FlexInitFrame,4)];
gnd_r_handlcom=[B(FlexInitFrame,8),B(FlexInitFrame,9),B(FlexInitFrame,10)];
gnd_r_handr=gnd_r_handrcom-handr_r_handrcom;
gnd_r_handl=gnd_r_handlcom-handl_r_handlcom;

% Find and store box markers from the trc file.
TFR_index=MeasuredMarker.getMarkerIndex('TFR');
TFL_index=MeasuredMarker.getMarkerIndex('TFL');
TBR_index=MeasuredMarker.getMarkerIndex('TBR');
TBL_index=MeasuredMarker.getMarkerIndex('TBL');
FHR_index=MeasuredMarker.getMarkerIndex('FHR');
FHL_index=MeasuredMarker.getMarkerIndex('FHL');
BHR_index=MeasuredMarker.getMarkerIndex('BHR');
BHL_index=MeasuredMarker.getMarkerIndex('BHL');
C=Storage();
MeasuredMarker.makeRdStorage(C);
D=C.getStateVector(0);
E=D.getData();

% Divide marker data by 1000 to change from mm to m.
Mrk1(1,1)=E.get(TFR_index*3)/1000;
Mrk1(1,2)=E.get(TFR_index*3+1)/1000;
Mrk1(1,3)=E.get(TFR_index*3+2)/1000;
Mrk2(1,1)=E.get(TFL_index*3)/1000;
Mrk2(1,2)=E.get(TFL_index*3+1)/1000;
Mrk2(1,3)=E.get(TFL_index*3+2)/1000;
Mrk3(1,1)=E.get(TBL_index*3)/1000;
Mrk3(1,2)=E.get(TBL_index*3+1)/1000;
Mrk3(1,3)=E.get(TBL_index*3+2)/1000;
Mrk4(1,1)=E.get(TBR_index*3)/1000;
Mrk4(1,2)=E.get(TBR_index*3+1)/1000;
Mrk4(1,3)=E.get(TBR_index*3+2)/1000;
Mrk5(1,1)=E.get(FHL_index*3)/1000;
Mrk5(1,2)=E.get(FHL_index*3+1)/1000;
Mrk5(1,3)=E.get(FHL_index*3+2)/1000;
Mrk6(1,1)=E.get(BHL_index*3)/1000;
Mrk6(1,2)=E.get(BHL_index*3+1)/1000;
Mrk6(1,3)=E.get(BHL_index*3+2)/1000;        
Mrk7(1,1)=E.get(FHR_index*3)/1000;
Mrk7(1,2)=E.get(FHR_index*3+1)/1000;
Mrk7(1,3)=E.get(FHR_index*3+2)/1000;
Mrk8(1,1)=E.get(BHR_index*3)/1000;
Mrk8(1,2)=E.get(BHR_index*3+1)/1000;
Mrk8(1,3)=E.get(BHR_index*3+2)/1000;
Mrk=[Mrk1;Mrk2;Mrk3;Mrk4;Mrk5;Mrk6;Mrk7;Mrk8];

% This code section ensures the correct identification of right and left markers in the TRC file,
% irrespective of their naming convention.
flagr=1;
flagl=1;
xcom=mean(Mrk(:,1));
zcom=mean(Mrk(:,3));
    for mrknum=1:8
        if Mrk(mrknum,3)<zcom
        RightMrks(flagr,:)=Mrk(mrknum,:);
        flagr=flagr+1;
        else
        LeftMrks(flagl,:)=Mrk(mrknum,:);
        flagl=flagl+1;
        end
    end
RightSortingMat=sort(RightMrks(:,2));
LeftSortingMat=sort(LeftMrks(:,2));
flagrt=1;
flagrh=1;
flaglt=1;
flaglh=1;
    for mrknum=1:4
        if RightMrks(mrknum,2)==RightSortingMat(1)|RightMrks(mrknum,2)==RightSortingMat(2)
        RightHndlMrks(flagrh,:)=RightMrks(mrknum,:);
        flagrh=flagrh+1;
        else
        RightTopMrks(flagrt,:)=RightMrks(mrknum,:);
        flagrt=flagrt+1;
        end      
    end
    for mrknum=1:4
        if LeftMrks(mrknum,2)==LeftSortingMat(1)|LeftMrks(mrknum,2)==LeftSortingMat(2)
        LeftHndlMrks(flaglh,:)=LeftMrks(mrknum,:);
        flaglh=flaglh+1;
        else
        LeftTopMrks(flaglt,:)=LeftMrks(mrknum,:);
        flaglt=flaglt+1;
        end      
    end
% The box's center of mass (COM) is assumed to be 13.5 cm below the top markers, based on the study's box dimensions.
% Adjust this value as needed for your specific study.
ycom=RightTopMrks(1,2)-0.135;

% Calculate the positions of the Weld Joint relative to the parent bodies (handr and handl).
BoxCOM=[xcom ycom zcom];
xr=mean([RightHndlMrks(1,1),RightHndlMrks(2,1)]);
zr=mean([RightHndlMrks(1,3),RightHndlMrks(2,3)]);
yr=ycom;
xl=mean([LeftHndlMrks(1,1),LeftHndlMrks(2,1)]);
zl=mean([LeftHndlMrks(1,3),LeftHndlMrks(2,3)]);
yl=ycom;
Rhandle=[xr yr zr];
Lhandle=[xl yl zl];
handr_r_weld=(handr_R_gnd*(Rhandle-gnd_r_handr)')';
handl_r_weld=(handl_R_gnd*(Lhandle-gnd_r_handl)')';

% Calculate the positions of the Weld Joint with respect to the child bodies (boxr and boxl).
boxr_com=mean([BoxCOM;Rhandle]);
boxl_com=mean([BoxCOM;Lhandle]);
boxr_r_weld=Rhandle-boxr_com;
boxl_r_weld=Lhandle-boxl_com;

% The inertia properties of the box were determined based on the studied box's dimensions and mass.
% Users might need to adjust these properties according to their specific study requirements.
Boxmass=Load.getMass();
    if Boxmass==7
        Ixx=0.022786;
        Iyy=0.022786;
        Izz=0.03646;
    else 
        Ixx=0.03255;
        Iyy=0.03255;
        Izz=0.05208;
    end
I=[Ixx;Iyy;Izz;0;0;0];

% Create the half-box bodies using API.
Boxr=Body();
Boxl=Body();
Boxr.setName('Box_R');
Boxl.setName('Box_L');
Boxr.setMass(Boxmass/2);
Boxl.setMass(Boxmass/2);
InertiaProp=ArrayDouble();
InertiaProp.setSize(6);
    for nn=1:6
    InertiaProp.setitem(nn-1,I(nn));
    end
Boxr.setInertia(InertiaProp);
Boxl.setInertia(InertiaProp);
rightweld=WeldJoint();
leftweld=WeldJoint();
rightweld.setName('BoxR_handr_Jnt');
leftweld.setName('BoxL_handl_Jnt');
rightweld.setParentName('hand_R');
leftweld.setParentName('hand_L');

a1=Vec3(handr_r_weld(1),handr_r_weld(2),handr_r_weld(3));
a2=Vec3(handr_O_weld(1),handr_O_weld(2),handr_O_weld(3));
a3=Vec3(boxr_r_weld(1),boxr_r_weld(2),boxr_r_weld(3));
a4=Vec3(0,0,0);
rightweld.setLocationInParent(a1);
rightweld.setOrientationInParent(a2);
rightweld.setLocation(a3);
rightweld.setOrientation(a4);
    
a5=Vec3(handl_r_weld(1),handl_r_weld(2),handl_r_weld(3));
a6=Vec3(handl_O_weld(1),handl_O_weld(2),handl_O_weld(3));
a7=Vec3(boxl_r_weld(1),boxl_r_weld(2),boxl_r_weld(3));
a8=Vec3(0,0,0);
leftweld.setLocationInParent(a5);
leftweld.setOrientationInParent(a6);
leftweld.setLocation(a7);
leftweld.setOrientation(a8);
    
Boxr.setJoint(rightweld);
Boxl.setJoint(leftweld);
FlexInitModel.addBody(Boxr);
FlexInitModel.addBody(Boxl);
    
% Add the Weld Constraint between half-boxes.
weldconstraint=WeldConstraint();
weldconstraint.setName('BoxR_BoxL_con');
weldconstraint.setBody1ByName('Box_R');
weldconstraint.setBody2ByName('Box_L');
boxr_r_weldconst=BoxCOM-boxr_com;
boxl_r_weldconst=BoxCOM-boxl_com;
a9=Vec3(boxr_r_weldconst(1),boxr_r_weldconst(2),boxr_r_weldconst(3));
a10=Vec3(boxl_r_weldconst(1),boxl_r_weldconst(2),boxl_r_weldconst(3));
a11=Vec3(0,0,0);
weldconstraint.set_location_body_1(a9);
weldconstraint.set_location_body_2(a10);
weldconstraint.set_orientation_body_1(a11);
weldconstraint.set_orientation_body_2(a11);
FlexInitModel.addConstraint(weldconstraint);

% Write the new model into the trial folder.
setupFile=['FlexInitWithBox.osim']; 
FlexInitModel.print([TrialModelFilePath setupFile]);

%% Generating P2_APP3_IK.osim

% Load the previously created FlexInitWithBox model with half boxes
%(FlexInitWithBox.osim) to include the box markers for the Inverse Kinematics (IK) analysis (P2_APP3_IK.osim).

% Create a new model based on the Load_MrkGND.osim, which includes the box markers.
LoadMrkGndModel=Model('Load_MrkGND.osim');

TFR_index=MeasuredMarker.getMarkerIndex('TFR');
TFL_index=MeasuredMarker.getMarkerIndex('TFL');
TBR_index=MeasuredMarker.getMarkerIndex('TBR');
TBL_index=MeasuredMarker.getMarkerIndex('TBL');
FHR_index=MeasuredMarker.getMarkerIndex('FHR');
FHL_index=MeasuredMarker.getMarkerIndex('FHL');
BHR_index=MeasuredMarker.getMarkerIndex('BHR');
BHL_index=MeasuredMarker.getMarkerIndex('BHL');

% Extract the z-coordinates of the box markers to determine which markers 
% should be attached to the 'Box_r' (right half box) and which should be 
% attached to the 'Box_l' (left half box) bodies. 
% (The division by 1000 converts mm to meters.)
C=Storage();
MeasuredMarker.makeRdStorage(C);
D=C.getStateVector(0);
E=D.getData();
Mrk1z=E.get(TFR_index*3+2)/1000;
Mrk2z=E.get(TFL_index*3+2)/1000;
Mrk3z=E.get(TBL_index*3+2)/1000;
Mrk4z=E.get(TBR_index*3+2)/1000;
Mrk5z=E.get(FHL_index*3+2)/1000;
Mrk6z=E.get(BHL_index*3+2)/1000;
Mrk7z=E.get(FHR_index*3+2)/1000;
Mrk8z=E.get(BHR_index*3+2)/1000;
zcom=mean([Mrk1z,Mrk2z,Mrk3z,Mrk4z,Mrk5z,Mrk6z,Mrk7z,Mrk8z]);
     
% Create a MATLAB model from FlexInitWithBox to work with it through API.
FlexInitModelWithBox=Model('FlexInitWithBox.osim');
bodynumbers=FlexInitModelWithBox.getBodySet().getSize();
% Retrieve the right and left half boxes from the model.
Boxr=FlexInitModelWithBox.getBodySet().get(bodynumbers-2);
Boxl=FlexInitModelWithBox.getBodySet().get(bodynumbers-1);
% Retrieve the marker set from LoadMrkGndModel.
loadmrkset=LoadMrkGndModel.getMarkerSet();
numloadmrks=loadmrkset.getSize();
% Retrieve the marker set from FlexInitModelWithBox.
flexinitmrkset=FlexInitModelWithBox.getMarkerSet();

% Append the markers from LoadMrkGndModel to FlexInitModelWithBox.
    for pp=1:numloadmrks
       flexinitmrkset.adoptAndAppend(loadmrkset.get(pp-1)); 
    end
numtotmarkers=flexinitmrkset.getSize();
FlexInitModelWithBox.initSystem();
initstate=FlexInitModelWithBox.getWorkingState();
% Assign each marker to the appropriate half-box based on its z-coordinate
% and create P2_APP3_IK.osim
    for kk=1:numloadmrks
        marker=loadmrkset.get(kk-1);
        newmarker=flexinitmrkset.get(numtotmarkers-numloadmrks+kk-1);
        a1=Vec3();
        marker.getOffset(a1);      
        if a1.get(2)<zcom
        newmarker.changeBodyPreserveLocation(initstate,Boxr);
        else
        newmarker.changeBodyPreserveLocation(initstate,Boxl);
        end
        clear a1
    end  
setupFile=['P2_APP3_IK.osim'];

FlexInitModelWithBox.print([TrialModelFilePath setupFile]);
    
